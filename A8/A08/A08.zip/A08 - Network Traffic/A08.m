% --- High ---

    % High to Medium l = 1

        

    % High to Down l = 0.05

% --- Medium ---

    % Medium to High l = 0.4

    % Medium to Low l = 0.6

    % Medium to Down l = 0.05

% --- Low ---

    % Low to Medium l = 0.33

    % Low to Down l = 0.05

% --- Down ---
    
    % Remain in Down l = 6

    % Down to Low p = 0.6

    % Down to Medium p = 0.3

    % Down to High p = 0.1
p0 = [0, 1, 0, 0];

l01 = 0.33;
l02 = 0;
l03 = 0.05;
l12 = 0.4;
l13 = 0.05;
l23 = 0.05;

m10 = 0.6;
m20 = 0;
m21 = 1;
m30 = 6 * 0.6;
m31 = 6 * 0.3;
m32 = 6 * 0.1;

s1 = -(l01 + l02 + l03); 
s2 = -(m10 + l12 + l13);
s3 = -(m20 + m21 + l23);
s4 = -(m30 + m31 + m32);

%      0     1       2       3
Q = [ s1,   l01,    l02,    l03;  %0
      m10,  s2,    l12,    l13;  %1  
      m20,  m21,    s3,     l23;  %2
      m30,  m31,    m32,    s4];  %3

Q

[t, Sol] = ode45(@(t,x) Q'*x, [0 8], p0');

plot(t, Sol, "-");
       